
export interface PricingPackage {
  id: string;
  name: string;
  price: string;
  durationMonths: number;
  features: string[];
}

export interface WeightEntry {
  date: string;
  weight: number;
}

export interface PromoCode {
  id: string;
  code: string;
  discount: string; // e.g. "10%" or "100" (fixed amount)
  deadline: string;
}

export interface Offer {
  id: string;
  title: string;
  description: string;
  showLimit: number;
  isActive: boolean;
}

export interface User {
  id: string; // Login ID
  password: string;
  name: string;
  email: string;
  phone: string;
  gender: 'MALE' | 'FEMALE';
  dob: string; // YYYY-MM-DD
  createdAt: string;
  
  // Physical Stats
  height?: number; // cm
  currentWeight?: number; // kg
  weightHistory: WeightEntry[];
  
  // Subscription
  subscriptionStart?: string;
  subscriptionEnd?: string;
  isActive: boolean;
  
  // Plans
  workoutPlan: string;
  dietPlan: string;
  notes: string;

  // Ads
  seenOffers: Record<string, number>;
}

export interface AdminProfile {
  id: string;
  email: string;
  phone: string;
  password: string;
}

export interface AppConfig {
  admin: AdminProfile;
}

export type ViewState = 'PUBLIC' | 'LOGIN' | 'ADMIN' | 'CLIENT';
