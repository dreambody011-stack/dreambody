
import React, { useState, useEffect } from 'react';
import { User, PricingPackage, PromoCode, Offer } from '../types';
import * as Storage from '../services/storage';
import { 
  Download, Lock, Target, Utensils, 
  Dumbbell, MessageSquare, Instagram, Settings, UserCircle, Save,
  Megaphone, X, Ticket, CheckCircle, Percent
} from 'lucide-react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer 
} from 'recharts';
import ChatInterface from './ChatInterface';

interface ClientDashboardProps {
  user: User;
  refreshUser: () => void;
}

const ClientDashboard: React.FC<ClientDashboardProps> = ({ user, refreshUser }) => {
  const [activeTab, setActiveTab] = useState<'HOME' | 'WORKOUT' | 'DIET' | 'AI' | 'PRICING' | 'PROFILE'>('HOME');
  const [newWeight, setNewWeight] = useState('');
  
  // Offers / Ads State
  const [activeOffers, setActiveOffers] = useState<Offer[]>([]);
  const [currentAd, setCurrentAd] = useState<Offer | null>(null);

  // Pricing State
  const [packages, setPackages] = useState<PricingPackage[]>([]);
  const [promoCodeInput, setPromoCodeInput] = useState('');
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(null);
  const [promoError, setPromoError] = useState('');

  // Profile Update State
  const [profileForm, setProfileForm] = useState({
      height: user.height || 0,
      weight: user.currentWeight || 0,
      gender: user.gender || 'MALE',
      oldPassword: '',
      newPassword: '',
      confirmPassword: ''
  });

  // Init Data & Check Ads
  useEffect(() => {
    const allOffers = Storage.getOffers().filter(o => o.isActive);
    setActiveOffers(allOffers);
    setPackages(Storage.getPackages());

    // Check for an unseen ad to display as popup
    const userSeen = user.seenOffers || {};
    const adToShow = allOffers.find(offer => (userSeen[offer.id] || 0) < offer.showLimit);
    
    if (adToShow) {
        // Small delay for better UX
        const timer = setTimeout(() => setCurrentAd(adToShow), 1000);
        return () => clearTimeout(timer);
    }
  }, [user]);

  // Subscription Check
  const isExpired = !user.isActive || (user.subscriptionEnd && new Date(user.subscriptionEnd) < new Date());
  
  const handleDownload = (filename: string, content: string) => {
    const element = document.createElement("a");
    const file = new Blob([content], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = filename;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const handleAddWeight = () => {
    if(!newWeight) return;
    Storage.addWeightEntry(user.id, parseFloat(newWeight));
    setNewWeight('');
    refreshUser();
  };

  const handleCloseAd = () => {
      if (currentAd) {
          Storage.markOfferSeen(user.id, currentAd.id);
          setCurrentAd(null);
          // Refresh user to update seen counts in local state if needed, 
          // though typically we just close the modal.
          refreshUser();
      }
  };

  const calculateAge = () => {
      if(!user.dob) return '--';
      const birthDate = new Date(user.dob);
      const diff = Date.now() - birthDate.getTime();
      const ageDate = new Date(diff); 
      return Math.abs(ageDate.getUTCFullYear() - 1970);
  };

  const handleUpdateProfile = (e: React.FormEvent) => {
      e.preventDefault();
      
      let updatedUser = { 
        ...user, 
        height: Number(profileForm.height), 
        currentWeight: Number(profileForm.weight),
        gender: profileForm.gender as 'MALE' | 'FEMALE'
      };

      // Password Change Logic
      if (profileForm.newPassword) {
          if (profileForm.oldPassword !== user.password) {
              alert("Old password is incorrect.");
              return;
          }
          if (profileForm.newPassword !== profileForm.confirmPassword) {
              alert("New passwords do not match.");
              return;
          }
          updatedUser.password = profileForm.newPassword;
      }

      Storage.updateUser(updatedUser);
      alert("Profile Updated Successfully!");
      setProfileForm({ ...profileForm, oldPassword: '', newPassword: '', confirmPassword: '' });
      refreshUser();
  };

  // Pricing Logic
  const handleApplyPromo = () => {
      setPromoError('');
      setAppliedPromo(null);
      
      const codes = Storage.getPromoCodes();
      const code = codes.find(c => c.code === promoCodeInput.trim().toUpperCase());
      
      if (!code) {
          setPromoError('Invalid Promo Code');
          return;
      }
      
      if (new Date(code.deadline) < new Date()) {
          setPromoError('Promo Code Expired');
          return;
      }

      setAppliedPromo(code);
  };

  const getDiscountedPrice = (priceStr: string) => {
      const price = parseFloat(priceStr);
      if (!appliedPromo) return price;

      if (appliedPromo.discount.includes('%')) {
          const percentage = parseFloat(appliedPromo.discount.replace('%', ''));
          return price - (price * (percentage / 100));
      } else {
          const fixed = parseFloat(appliedPromo.discount);
          return Math.max(0, price - fixed);
      }
  };

  const chartData = user.weightHistory.length > 0 ? user.weightHistory : [];

  return (
    <div className="max-w-7xl mx-auto px-4 py-8 relative">
      
      {/* Active Offers Bar */}
      {activeOffers.length > 0 && (
          <div className="bg-gradient-to-r from-cyan-900/40 to-blue-900/40 border border-cyan-500/30 rounded-lg p-3 mb-6 flex items-center overflow-hidden">
              <Megaphone className="h-5 w-5 text-cyan-400 mr-3 flex-shrink-0 animate-pulse" />
              <div className="whitespace-nowrap overflow-x-auto no-scrollbar flex gap-8 text-sm text-cyan-100 font-medium">
                  {activeOffers.map(offer => (
                      <span key={offer.id} className="flex items-center">
                          <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full mr-2"></span>
                          {offer.title}: {offer.description}
                      </span>
                  ))}
              </div>
          </div>
      )}

      {/* Welcome Header */}
      <div className="mb-8">
         <h1 className="text-3xl font-bold text-white">Welcome back, <span className="text-cyan-400">{user.name}</span></h1>
         <div className="flex items-center mt-2 text-slate-400 text-sm">
            <span className={`inline-block w-2 h-2 rounded-full mr-2 ${isExpired ? 'bg-red-500' : 'bg-green-500'}`}></span>
            {isExpired ? 'Subscription Expired / Inactive' : 'Active Member'}
            {user.subscriptionEnd && <span className="ml-4">Expires: {user.subscriptionEnd}</span>}
         </div>
      </div>

      {/* Tabs */}
      <div className="flex overflow-x-auto space-x-2 mb-8 pb-2 border-b border-slate-800">
        {[
          { id: 'HOME', icon: Target, label: 'Progress' },
          { id: 'WORKOUT', icon: Dumbbell, label: 'Workout Plan' },
          { id: 'DIET', icon: Utensils, label: 'Diet Plan' },
          { id: 'AI', icon: MessageSquare, label: 'AI Coach' },
          { id: 'PRICING', icon: Ticket, label: 'Plans & Pricing' },
          { id: 'PROFILE', icon: Settings, label: 'Settings' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`flex items-center px-6 py-3 rounded-t-lg font-medium transition-colors whitespace-nowrap ${
              activeTab === tab.id 
              ? 'bg-slate-800 text-cyan-400 border-b-2 border-cyan-500' 
              : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <tab.icon className="mr-2 h-4 w-4" /> {tab.label}
          </button>
        ))}
      </div>

      {/* Content Area */}
      <div className="min-h-[400px]">
        {activeTab === 'HOME' && (
          <div className="space-y-8">
            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
               <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-xs uppercase font-bold">Current Weight</div>
                  <div className="text-2xl font-bold text-white mt-1">{user.currentWeight || '--'} <span className="text-sm font-normal text-slate-500">kg</span></div>
               </div>
               <div className="bg-slate-900 p-4 rounded-xl border border-slate-800">
                  <div className="text-slate-500 text-xs uppercase font-bold">Age</div>
                  <div className="text-xl font-bold text-white mt-1">{calculateAge()} <span className="text-sm font-normal text-slate-500">years</span></div>
               </div>
               <a href="https://instagram.com" target="_blank" rel="noreferrer" className="col-span-2 bg-gradient-to-r from-purple-600 to-pink-600 rounded-xl p-4 flex items-center justify-between group cursor-pointer hover:opacity-90 transition-opacity">
                  <div className="text-white">
                    <div className="font-bold">Contact Coach</div>
                    <div className="text-xs text-white/80">DM on Instagram</div>
                  </div>
                  <Instagram className="text-white h-8 w-8 group-hover:scale-110 transition-transform" />
               </a>
            </div>

            {/* Chart */}
            <div className="bg-slate-900 border border-slate-800 rounded-xl p-6">
               <h3 className="text-lg font-bold text-white mb-6">Weight Progression</h3>
               <div className="h-64 w-full">
                 <ResponsiveContainer width="100%" height="100%">
                   <LineChart data={chartData}>
                     <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                     <XAxis dataKey="date" stroke="#64748b" tick={{fontSize: 12}} />
                     <YAxis stroke="#64748b" tick={{fontSize: 12}} domain={['auto', 'auto']} />
                     <Tooltip 
                        contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', color: '#fff' }}
                     />
                     <Line type="monotone" dataKey="weight" stroke="#06b6d4" strokeWidth={3} dot={{r: 4, fill: '#06b6d4'}} />
                   </LineChart>
                 </ResponsiveContainer>
               </div>
               
               {/* Update Weight */}
               <div className="mt-6 flex items-end gap-4 max-w-sm">
                  <div className="flex-1">
                    <label className="text-xs text-slate-500 block mb-1">Log Today's Weight</label>
                    <input 
                      type="number" 
                      value={newWeight}
                      onChange={(e) => setNewWeight(e.target.value)}
                      placeholder="e.g., 85.5"
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:border-cyan-500 outline-none"
                    />
                  </div>
                  <button 
                    onClick={handleAddWeight}
                    className="bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-lg font-medium"
                  >
                    Log
                  </button>
               </div>
            </div>
          </div>
        )}

        {(activeTab === 'WORKOUT' || activeTab === 'DIET') && (
          <div className="relative">
             {isExpired && (
                <div className="absolute inset-0 z-10 bg-slate-950/80 backdrop-blur-sm flex flex-col items-center justify-center text-center p-6 border border-slate-800 rounded-2xl">
                   <Lock className="h-16 w-16 text-red-500 mb-4" />
                   <h2 className="text-2xl font-bold text-white mb-2">Access Locked</h2>
                   <p className="text-slate-400 max-w-md">Your subscription is expired or inactive. Please contact your coach to unlock your plan.</p>
                </div>
             )}
             
             <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 min-h-[500px]">
                <div className="flex justify-between items-start mb-6 border-b border-slate-800 pb-4">
                   <h2 className="text-2xl font-bold text-white">
                      {activeTab === 'WORKOUT' ? 'My Workout Routine' : 'My Nutrition Plan'}
                   </h2>
                   <button 
                      onClick={() => handleDownload(
                        `${activeTab}_PLAN_${user.id}.txt`, 
                        activeTab === 'WORKOUT' ? user.workoutPlan : user.dietPlan
                      )}
                      disabled={isExpired}
                      className="flex items-center text-cyan-400 hover:text-cyan-300 disabled:opacity-0"
                   >
                      <Download className="mr-2 h-5 w-5" /> Download
                   </button>
                </div>
                <div className="prose prose-invert max-w-none whitespace-pre-wrap font-mono text-sm text-slate-300">
                   {activeTab === 'WORKOUT' ? user.workoutPlan : user.dietPlan}
                </div>
             </div>
          </div>
        )}

        {activeTab === 'AI' && (
          <ChatInterface user={user} />
        )}

        {activeTab === 'PRICING' && (
          <div className="space-y-8">
              {/* Promo Code Input */}
              <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="flex-1 w-full">
                      <h3 className="text-lg font-bold text-white mb-2 flex items-center"><Ticket className="mr-2 h-5 w-5 text-cyan-500" /> Have a Promo Code?</h3>
                      <div className="flex gap-2">
                          <input 
                            type="text" 
                            value={promoCodeInput}
                            onChange={(e) => setPromoCodeInput(e.target.value)}
                            placeholder="Enter Code (e.g. SUMMER24)"
                            className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-4 py-2 text-white uppercase placeholder-slate-600"
                          />
                          <button onClick={handleApplyPromo} className="bg-slate-800 hover:bg-cyan-900 text-white px-6 py-2 rounded-lg font-bold border border-slate-700 hover:border-cyan-500 transition-all">
                              Apply
                          </button>
                      </div>
                      {promoError && <p className="text-red-400 text-sm mt-2">{promoError}</p>}
                      {appliedPromo && (
                          <p className="text-green-400 text-sm mt-2 flex items-center">
                              <CheckCircle className="h-4 w-4 mr-1" /> 
                              Code Applied! {appliedPromo.discount.includes('%') ? appliedPromo.discount : `${appliedPromo.discount} EGY`} OFF
                          </p>
                      )}
                  </div>
              </div>

              {/* Packages Grid */}
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {packages.map(pkg => {
                      const finalPrice = getDiscountedPrice(pkg.price);
                      const hasDiscount = finalPrice < parseFloat(pkg.price);
                      
                      return (
                        <div key={pkg.id} className="bg-slate-900 border border-slate-800 rounded-2xl p-6 relative overflow-hidden group hover:border-cyan-500/50 transition-colors">
                            {hasDiscount && (
                                <div className="absolute top-0 right-0 bg-red-600 text-white text-xs font-bold px-3 py-1 rounded-bl-xl">
                                    SALE
                                </div>
                            )}
                            <h3 className="text-xl font-bold text-white mb-2">{pkg.name}</h3>
                            <div className="mb-6">
                                {hasDiscount ? (
                                    <div className="flex items-end gap-2">
                                        <span className="text-3xl font-extrabold text-white">{finalPrice.toFixed(0)} <span className="text-sm font-normal text-slate-400">EGY</span></span>
                                        <span className="text-lg text-slate-500 line-through decoration-red-500">{pkg.price}</span>
                                    </div>
                                ) : (
                                    <div className="text-3xl font-extrabold text-white">{pkg.price} <span className="text-sm font-normal text-slate-400">EGY</span></div>
                                )}
                                <div className="text-xs text-slate-500 mt-1">{pkg.durationMonths} Month Duration</div>
                            </div>
                            
                            <ul className="space-y-3 mb-8">
                                {pkg.features.map((feat, i) => (
                                    <li key={i} className="flex items-start text-sm text-slate-300">
                                        <CheckCircle className="h-4 w-4 text-cyan-500 mr-2 flex-shrink-0 mt-0.5" />
                                        {feat}
                                    </li>
                                ))}
                            </ul>

                            <button onClick={() => {
                                // Just a visual action for now as per instructions (admin activates)
                                alert(`Request for ${pkg.name} sent to Coach! Please contact on Instagram to finalize payment.`);
                            }} className="w-full bg-cyan-600 hover:bg-cyan-500 text-white py-3 rounded-xl font-bold transition-all shadow-lg shadow-cyan-900/30">
                                Request Plan
                            </button>
                        </div>
                      );
                  })}
              </div>
          </div>
        )}

        {activeTab === 'PROFILE' && (
             <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 max-w-2xl mx-auto">
                 <h2 className="text-2xl font-bold text-white mb-6 flex items-center">
                     <UserCircle className="mr-3 h-6 w-6 text-cyan-500"/> Account Settings
                 </h2>
                 <form onSubmit={handleUpdateProfile} className="space-y-6">
                     <div className="grid md:grid-cols-2 gap-6">
                         <div>
                             <label className="text-xs text-slate-500 uppercase font-bold">Full Name</label>
                             <div className="mt-1 text-white text-lg">{user.name}</div>
                         </div>
                         <div>
                             <label className="text-xs text-slate-500 uppercase font-bold">User ID</label>
                             <div className="mt-1 text-cyan-400 text-lg font-mono">{user.id}</div>
                         </div>
                         <div>
                             <label className="text-xs text-slate-500 uppercase font-bold">Email</label>
                             <div className="mt-1 text-slate-300">{user.email || 'N/A'}</div>
                         </div>
                         <div>
                             <label className="text-xs text-slate-500 uppercase font-bold">Gender</label>
                             <select 
                                value={profileForm.gender}
                                onChange={e => setProfileForm({...profileForm, gender: e.target.value as any})}
                                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white mt-1"
                             >
                                <option value="MALE">Male</option>
                                <option value="FEMALE">Female</option>
                             </select>
                         </div>
                     </div>
                     
                     <hr className="border-slate-800 my-6" />
                     
                     <h3 className="text-lg font-bold text-white">Update Stats</h3>
                     <div className="grid md:grid-cols-2 gap-4">
                         <div>
                             <label className="text-sm text-slate-400">Height (cm)</label>
                             <input 
                                type="number" 
                                value={profileForm.height}
                                onChange={e => setProfileForm({...profileForm, height: Number(e.target.value)})}
                                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-white mt-1"
                             />
                         </div>
                         <div>
                             <label className="text-sm text-slate-400">Current Weight (kg)</label>
                             <input 
                                type="number" 
                                value={profileForm.weight}
                                onChange={e => setProfileForm({...profileForm, weight: Number(e.target.value)})}
                                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-white mt-1"
                             />
                         </div>
                     </div>

                     <hr className="border-slate-800 my-6" />

                     <h3 className="text-lg font-bold text-white">Change Password</h3>
                     <div className="space-y-4">
                         <div>
                             <label className="text-sm text-slate-400">Current Password</label>
                             <input 
                                type="password" 
                                value={profileForm.oldPassword}
                                onChange={e => setProfileForm({...profileForm, oldPassword: e.target.value})}
                                className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-white mt-1"
                                placeholder="Enter current password to save changes"
                             />
                         </div>
                         <div className="grid md:grid-cols-2 gap-4">
                            <div>
                                <label className="text-sm text-slate-400">New Password</label>
                                <input 
                                    type="password" 
                                    value={profileForm.newPassword}
                                    onChange={e => setProfileForm({...profileForm, newPassword: e.target.value})}
                                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-white mt-1"
                                />
                            </div>
                            <div>
                                <label className="text-sm text-slate-400">Confirm New Password</label>
                                <input 
                                    type="password" 
                                    value={profileForm.confirmPassword}
                                    onChange={e => setProfileForm({...profileForm, confirmPassword: e.target.value})}
                                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-3 text-white mt-1"
                                />
                            </div>
                         </div>
                     </div>

                     <div className="flex justify-end pt-4">
                         <button type="submit" className="bg-cyan-600 hover:bg-cyan-500 text-white px-8 py-3 rounded-lg font-bold flex items-center">
                             <Save className="mr-2 h-5 w-5" /> Save Changes
                         </button>
                     </div>
                 </form>
             </div>
        )}
      </div>

      {/* Offer / Ad Modal */}
      {currentAd && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
              <div className="bg-slate-900 border-2 border-cyan-500 rounded-2xl max-w-md w-full p-8 shadow-2xl shadow-cyan-500/20 relative">
                  <button onClick={handleCloseAd} className="absolute top-4 right-4 text-slate-400 hover:text-white">
                      <X className="h-6 w-6" />
                  </button>
                  <div className="flex justify-center mb-6">
                      <div className="bg-cyan-900/50 p-4 rounded-full">
                          <Megaphone className="h-10 w-10 text-cyan-400 animate-bounce" />
                      </div>
                  </div>
                  <h2 className="text-2xl font-bold text-white text-center mb-4">{currentAd.title}</h2>
                  <p className="text-slate-300 text-center mb-8 leading-relaxed">
                      {currentAd.description}
                  </p>
                  <button onClick={handleCloseAd} className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-3 rounded-xl transition-all transform hover:scale-[1.02]">
                      GOT IT!
                  </button>
              </div>
          </div>
      )}
    </div>
  );
};

export default ClientDashboard;
